This zip file contain all the work done by Rishit Jain in the course of internship from 1st march 2024 to 1st april 2024

The files in the zip file are - jiodatavisual.py, it is the main file which has the following packages - 
streamlit 
pandas
datetime
sklearn
matplotlib.pyplot

the user needs to run the streamlit app from terminal to view the data

the second file in the zip file is testdata.csv - it is random data that was generated 
